//
//  TCRDemoLoadingView.swift
//  TcrDemo
//
//  Created by xxhape on 2024/2/20.
//

import Foundation
import UIKit

class TCRDemoLoadingView: UIView {
    private var processLab: UILabel!
    private var processFrame: CGRect!
    private var processView: UIView!
    private var fakeProcessTimer: Timer?
    
    var processValue: Int = 0 {
        didSet {
            processValue = max(0, min(processValue, 100))
            if processValue == oldValue {
                return
            }
            DispatchQueue.main.async {
                if self.processValue >= 100 {
                    self.isHidden = true
                    return
                }
                self.processLab.text = "正在全力加载游戏···\(self.processValue)%"
                var newFrame = self.processFrame
                newFrame?.size.width = self.processFrame.size.width * CGFloat(self.processValue) / 100
                self.processView.frame = newFrame!
            }
            NSLog("setProcessValue:%d", processValue)
        }
    }
    
    override var isHidden: Bool {
        didSet {
            super.isHidden = isHidden
            if isHidden {
                fakeProcessTimer?.invalidate()
                fakeProcessTimer = nil
            } else {
                fakeProcessTimer?.invalidate()
                fakeProcessTimer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true) { [weak self] _ in
                    guard let self = self else { return }
                    if self.processValue < 98 {
                        self.processValue += 1
                    }
                }
            }
        }
    }
    
    init(frame: CGRect, process: Int) {
        super.init(frame: frame)
        initSubviews()
        processValue = process
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func startFakeProcess() {
        // 默认4秒
        fakeProcessTimer = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            if self.processValue < 98 {
                self.processValue += 1
            }
        }
    }
    
    private func initSubviews() {
        let perPixel = self.bounds.size.width / 1920.0
        let bgImageView = UIImageView(frame: self.bounds)
        bgImageView.image = UIImage(named: "loading_bg")
        addSubview(bgImageView)

        let iconImageView = UIImageView(frame: CGRect(x: 520 * perPixel, y: 226 * perPixel, width: 880 * perPixel, height: 268 * perPixel))
        iconImageView.image = UIImage(named: "tcr_cloud")
        addSubview(iconImageView)

        processLab = UILabel(frame: CGRect(x: 750 * perPixel, y: 570 * perPixel, width: 420 * perPixel, height: 46 * perPixel))
        processLab.font = UIFont.systemFont(ofSize: 33 * perPixel)
        processLab.textColor = UIColor.init("81868C")
        addSubview(processLab)

        processFrame = CGRect(x: 660 * perPixel, y: 656 * perPixel, width: 600 * perPixel, height: 18 * perPixel)
        let processBgView = UIView(frame: processFrame)
        processBgView.layer.cornerRadius = 9 * perPixel
        processBgView.layer.backgroundColor = UIColor(white: 1, alpha: 0.2).cgColor
        addSubview(processBgView)

        processView = UIView(frame: processFrame)
        processView.layer.cornerRadius = 9 * perPixel
        processView.layer.backgroundColor = UIColor.init("2684FF").cgColor
        addSubview(processView)
    }

}

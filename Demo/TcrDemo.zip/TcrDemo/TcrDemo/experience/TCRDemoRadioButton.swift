//
//  TCRDemoRadioButton.swift
//  TcrDemo
//
//  Created by xxhape on 2024/2/20.
//

import UIKit

class TCRDemoRaidoSubBtn: UIView {
    private var titleView: UILabel!
    private var imageView: UIImageView!

    init(frame: CGRect, title: String, image: UIImage) {
        super.init(frame: frame)
        
        imageView = UIImageView(frame: CGRect(x: 0, y: 6, width: 10, height: 10))
        imageView.image = image
        addSubview(imageView)

        titleView = UILabel(frame: CGRect(x: 12, y: 5, width: 33, height: 12))
        titleView.font = UIFont.systemFont(ofSize: 10)
        titleView.textColor = UIColor.white
        titleView.text = title
        
        isUserInteractionEnabled = true
        addSubview(titleView)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setImage(_ image: UIImage) {
        imageView.image = image
    }

    func getTitle() -> String {
        return titleView.text ?? ""
    }
}

class TCRDemoRaidoButton: UIView {
    private var items: [String]!
    private var buttons: [TCRDemoRaidoSubBtn]!

    var selectedValue: String? {
        didSet {
            for button in buttons {
                if button.getTitle() == selectedValue {
                    button.alpha = 1.0
                } else {
                    button.alpha = 0.4
                }
            }
        }
    }

    init(frame: CGRect, name: String, items: [String]) {
        super.init(frame: frame)
        backgroundColor = UIColor(white: 0, alpha: 0.2)
        self.items = items

        let txtName = UILabel(frame: CGRect(x: 10, y: 5, width: 48, height: 12))
        txtName.backgroundColor = .clear
        txtName.font = UIFont.systemFont(ofSize: 10)
        txtName.textColor = .white
        txtName.textAlignment = .left
        txtName.text = name
        addSubview(txtName)

        let line = CALayer()
        line.frame = CGRect(x: 60, y: 7.5, width: 0.5, height: 7.5)
        line.backgroundColor = UIColor(red: 0.188, green: 0.392, blue: 0.694, alpha: 1).cgColor
        layer.addSublayer(line)

        buttons = []
        initSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func initSubviews() {
        var left: CGFloat = 76
        for item in items {
            let btn = TCRDemoRaidoSubBtn(frame: CGRect(x: left, y: 0, width: 45, height: frame.size.height), title: item, image: UIImage(named: "login_radio_unselected")!)
            let click = UITapGestureRecognizer(target: self, action: #selector(onClick(_:)))
            btn.addGestureRecognizer(click)
            left += 45 + 5

            addSubview(btn)
            buttons.append(btn)
        }
    }

    @objc private func onClick(_ gestureRecognizer: UITapGestureRecognizer) {
        guard let tappedButton = gestureRecognizer.view as? TCRDemoRaidoSubBtn else { return }
        
        setSelectedValue(tappedButton.getTitle())
    }

    func setSelectedValue(_ selectedValue: String) {
        if let oldValue = self.selectedValue, oldValue == selectedValue {
            return
        }
        
        self.selectedValue = selectedValue
        
        for button in buttons {
            if selectedValue == button.getTitle() {
                button.setImage(UIImage(named: "login_radio_selected")!)
            } else {
                button.setImage(UIImage(named: "login_radio_unselected")!)
            }
        }
    }
}

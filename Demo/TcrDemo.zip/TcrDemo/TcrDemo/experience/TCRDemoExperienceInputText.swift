//
//  TCRDemoExperienceInputText.swift
//  TcrDemo
//
//  Created by xxhape on 2024/2/20.
//

import UIKit

protocol TCRDemoInputDelegate: AnyObject {
    func onBeginEditing(_ view: UIView)
}

class TCRDemoExperienceInputText: UIView, UITextFieldDelegate {
    private var txtInput: UITextField!
    
    weak var inputDelegate: TCRDemoInputDelegate?

    init(frame: CGRect, name: String, oldValue: String?) {
        super.init(frame: frame)
        
        backgroundColor = UIColor(white: 0, alpha: 0.2)

        let txtName = UILabel(frame: CGRect(x: 10, y: 5, width: 48, height: 12))
        txtName.backgroundColor = UIColor.clear
        txtName.font = UIFont.systemFont(ofSize: 10)
        txtName.textColor = UIColor.white
        txtName.textAlignment = .left
        txtName.text = name
        addSubview(txtName)

        let line = CALayer()
        line.frame = CGRect(x: 60, y: 7.5, width: 0.5, height: 7.5)
        line.backgroundColor = UIColor.init("3064B0").cgColor
        layer.addSublayer(line)

        txtInput = UITextField(frame: CGRect(x: 76, y: 4.5, width: 100, height: 14))
        txtInput.backgroundColor = UIColor.clear
        txtInput.font = UIFont.systemFont(ofSize: 10)
        txtInput.textColor = UIColor.white
        txtInput.textAlignment = .left
        txtInput.keyboardType = .asciiCapable
        txtInput.returnKeyType = .done
        txtInput.delegate = self
        txtInput.autocorrectionType = .no
        let placedString = "请输入\(name)"
        let placedAttr = NSMutableAttributedString(string: placedString)
        placedAttr.addAttribute(.font, value: UIFont.systemFont(ofSize: 10), range: NSRange(location: 0, length: placedString.count))
        placedAttr.addAttribute(.foregroundColor, value: UIColor.init("CEDBED").cgColor, range: NSRange(location: 0, length: placedString.count))
        txtInput.attributedPlaceholder = placedAttr
        if let oldValue = oldValue, !oldValue.isEmpty {
            txtInput.text = oldValue
        }
        addSubview(txtInput)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - UITextFieldDelegate
    var text: String? {
        return txtInput.text
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        inputDelegate?.onBeginEditing(textField)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtInput.resignFirstResponder()
        return true
    }
}

//
//  TCRDemoExperience.swift
//  TcrDemo
//
//  Created by xxhape on 2024/2/20.
//


import UIKit

typealias httpResponseBlk = (Data?, URLResponse?, Error?) -> Void
class TCRDemoExperienceVC: UIViewController, TcrSessionObserver, TCRDemoInputDelegate, TCRAudioSessionDelegate {

    private var bgView: UIImageView!
    private var loginWindowView: UIView!
    private var loginBgLayer: CAGradientLayer!
    private var keyboardBgView: UIView!
    private var experienceCfg: NSMutableDictionary!
    
    private var isSimpleMode: Bool = false
    private var simpleModeBtn: UIButton!
    private var advanceModeBtn: UIButton!
    
    private var inputScrollView: UIScrollView!
    private var simpleCodeTxt: TCRDemoExperienceInputText!
    
    private var keyboardTop: CGFloat = 0.0
    private var currentInputView: UIView!
    private var advanceContentView: UIView!
    private var advanceCodeTxt: TCRDemoExperienceInputText!
    private var advanceGameId: TCRDemoExperienceInputText!
    private var advanceFps: TCRDemoExperienceInputText!
    private var advanceUserId: TCRDemoExperienceInputText!
    private var advanceHostUserId: TCRDemoExperienceInputText!
    private var advanceResolution: TCRDemoRaidoButton!
    private var advanceRole: TCRDemoRaidoButton!
    private var loadingView: TCRDemoLoadingView!
    private var userId: String?
    private var experienceCode: String?
    private var enableCustomAudioCapture: Bool = false
    
    private var startBtn: UIButton!

    var session: TcrSession!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        // 将加载的配置添加到可变字典中
        experienceCfg = NSMutableDictionary()
        if let config = loadConfig() {
            experienceCfg.addEntries(from: config)
        }
        initSubviews()
        let notification = Notification(name: Notification.Name("KeyboardNotification"), object: nil, userInfo: nil)
        let nsNotification = notification as NSNotification
        keyboardWillHide(nsNotification)   // 更新StartBtn的背景色
        
        view.addSubview(bgView)
        view.addSubview(loginWindowView)
        view.addSubview(keyboardBgView)
        view.addSubview(loadingView)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isHidden = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        NotificationCenter.default.removeObserver(self)
    }
    
    deinit {
        
    }
    
    func initSubviews() {
        bgView = UIImageView(image: UIImage(named: "login_bg"))
        bgView.frame = view.bounds

        loginWindowView = UIView(frame: CGRect(x: 0, y: 0, width: 275, height: 216))
        loginBgLayer = CAGradientLayer()
        loginBgLayer.frame = loginWindowView.bounds
        loginBgLayer.startPoint = CGPoint(x: 0, y: 0)
        loginBgLayer.endPoint = CGPoint(x: 0, y: 1)
        loginBgLayer.colors = [UIColor.init("1B4C9A").cgColor,
                               UIColor.init("0D2C61").cgColor]
        loginBgLayer.locations = [0.0, 1.0]
        loginWindowView.layer.addSublayer(loginBgLayer)
        loginWindowView.center = view.center
        loginWindowView.backgroundColor = .clear
        
        let iconView = UIImageView(image: UIImage(named: "tcr_cloud"))
        iconView.frame = CGRect(x: 41.5, y: 5, width: 192.5, height: 60)
        loginWindowView.addSubview(iconView)

        simpleModeBtn = createTabBtn(name: "快速体验", icon: "simple_mode")
        simpleModeBtn.frame = CGRect(x: 67.5, y: 75, width: 70, height: 21)
        loginWindowView.addSubview(simpleModeBtn)
        simpleModeBtn.addTarget(self, action: #selector(showMode(_:)), for: .touchUpInside)

        advanceModeBtn = createTabBtn(name: "高级模式", icon: "simple_mode")
        advanceModeBtn.frame = CGRect(x: 137.5, y: 75, width: 70, height: 21)
        loginWindowView.addSubview(advanceModeBtn)
        advanceModeBtn.addTarget(self, action: #selector(showMode(_:)), for: .touchUpInside)
        
        simpleModeBtn.backgroundColor = UIColor.init("006EFF")
        isSimpleMode = true

        let simpleCode = (experienceCfg["simple"] as? [String: Any])?["ExperienceCode"] as? String
        simpleCodeTxt = TCRDemoExperienceInputText(frame: CGRect(x: 0, y: 0, width: 225, height: 22.5),
                                                   name: "体验码",
                                                   oldValue: simpleCode)
        simpleCodeTxt.inputDelegate = self
        
        inputScrollView = UIScrollView(frame: CGRect(x: 25, y: 121, width: 225, height: 22.5))
        inputScrollView.contentSize = simpleCodeTxt.bounds.size
        inputScrollView.addSubview(simpleCodeTxt)
        loginWindowView.addSubview(inputScrollView)
        initAdvanceInput()

        startBtn = UIButton(frame: CGRect(x: 25, y: 168.5, width: 225, height: 22.5))
        startBtn.backgroundColor = UIColor.init("006EFF")
        startBtn.setTitle("启动", for: .normal)
        startBtn.setTitleColor(.white, for: .normal)
        startBtn.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size: 8)
        startBtn.addTarget(self, action: #selector(startExperience), for: .touchUpInside)
        loginWindowView.addSubview(startBtn)
        startBtn.backgroundColor = UIColor.init("006EFF20")

        keyboardBgView = UIView(frame: view.bounds)
        keyboardBgView.backgroundColor = .clear
        keyboardBgView.isUserInteractionEnabled = true
        keyboardBgView.isHidden = true

        let singleClick = UITapGestureRecognizer(target: self, action: #selector(hiddenKeyboard(_:)))
        keyboardBgView.addGestureRecognizer(singleClick)
        
        loadingView = TCRDemoLoadingView(frame: view.bounds, process: 0)
        loadingView.isHidden = true
        enableCustomAudioCapture = true
    }

    func initAdvanceInput() {
        var top: CGFloat = 0
        let inputHeight: CGFloat = 22.5
        advanceContentView = UIView(frame: CGRect.zero)
        advanceContentView.backgroundColor = .clear
        
        let advanceCfg = experienceCfg["advance"] as? [String: Any]
        advanceCodeTxt = TCRDemoExperienceInputText(frame: CGRect(x: 0, y: top, width: 225, height: inputHeight),
                                                   name: "体验码",
                                                   oldValue: advanceCfg?["ExperienceCode"] as? String)
        advanceCodeTxt.inputDelegate = self
        advanceContentView.addSubview(advanceCodeTxt)
        
        top += inputHeight + 0.5
        advanceGameId = TCRDemoExperienceInputText(frame: CGRect(x: 0, y: top, width: 225, height: inputHeight),
                                                  name: "GameId",
                                                  oldValue: advanceCfg?["GameId"] as? String)
        advanceGameId.inputDelegate = self
        advanceContentView.addSubview(advanceGameId)
        
        top += inputHeight + 0.5
        advanceFps = TCRDemoExperienceInputText(frame: CGRect(x: 0, y: top, width: 225, height: inputHeight),
                                                name: "帧率",
                                                oldValue: (advanceCfg?["Fps"] as? NSNumber)?.stringValue)
        advanceFps.inputDelegate = self
        advanceContentView.addSubview(advanceFps)
        
        top += inputHeight + 0.5
        advanceUserId = TCRDemoExperienceInputText(frame: CGRect(x: 0, y: top, width: 225, height: inputHeight),
                                                    name: "UserId",
                                                    oldValue: advanceCfg?["UserId"] as? String)
        advanceUserId.inputDelegate = self
        advanceContentView.addSubview(advanceUserId)
        
        top += inputHeight + 0.5
        advanceHostUserId = TCRDemoExperienceInputText(frame: CGRect(x: 0, y: top, width: 225, height: inputHeight),
                                                       name: "HostUserId",
                                                       oldValue: advanceCfg?["HostUserId"] as? String)
        advanceHostUserId.inputDelegate = self
        advanceContentView.addSubview(advanceHostUserId)
        
        top += inputHeight + 0.5
        advanceRole = TCRDemoRaidoButton(frame: CGRect(x: 0, y: top, width: 225, height: inputHeight),
                                         name: "角色",
                                         items: ["Player", "Viewer"])
        if let role = advanceCfg?["Role"] as? String {
            advanceRole.setSelectedValue(role)
        } else {
            advanceRole.setSelectedValue("Viewer")
        }
        advanceContentView.addSubview(advanceRole)

        top += inputHeight + 0.5
        advanceResolution = TCRDemoRaidoButton(frame: CGRect(x: 0, y: top, width: 225, height: inputHeight), name: "分辨率", items: ["1080p", "720p"])
        if let resolution = advanceCfg?["Resolution"] {
            advanceResolution.setSelectedValue(resolution as! String)
        } else {
            advanceResolution.setSelectedValue("1080p")
        }
        advanceContentView.addSubview(advanceResolution)
        advanceContentView.frame = CGRect(x: 0, y: 0, width: 225, height: top + inputHeight + 100)
        advanceContentView.isHidden = true
        inputScrollView.addSubview(advanceContentView)
    }
    
    @objc func showMode(_ sender: Any) {
        var isSimple = true
        if sender as? UIButton == advanceModeBtn {
            simpleModeBtn.backgroundColor = UIColor.init("3064B0")
            advanceModeBtn.backgroundColor = UIColor.init("006EFF")
            isSimple = false
        } else {
            simpleModeBtn.backgroundColor = UIColor.init("006EFF")
            advanceModeBtn.backgroundColor = UIColor.init("3064B0")
        }
        isSimpleMode = isSimple
        weak var weakSelf = self
        let center = view.center
        UIView.animate(withDuration: 0.35) {
            guard let strongSelf = weakSelf else { return }
            var scrollFrame = strongSelf.inputScrollView.frame
            if isSimple {
                strongSelf.loginWindowView.frame = CGRect(x: 0, y: 0, width: 275, height: 216)
                strongSelf.startBtn.frame = CGRect(x: 25, y: 168.5, width: 225, height: 22.5)
                scrollFrame.size.height = strongSelf.simpleCodeTxt.frame.size.height
                strongSelf.inputScrollView.contentSize = strongSelf.simpleCodeTxt.frame.size
            } else {
                strongSelf.loginWindowView.frame = CGRect(x: 0, y: 0, width: 275, height: 345)
                strongSelf.startBtn.frame = CGRect(x: 25, y: 297.5, width: 225, height: 22.5)
                scrollFrame.size.height = 166.5
                strongSelf.inputScrollView.contentSize = strongSelf.advanceContentView.frame.size
            }
            strongSelf.inputScrollView.frame = scrollFrame
            strongSelf.advanceContentView.isHidden = isSimple
            strongSelf.simpleCodeTxt.isHidden = !isSimple
            strongSelf.loginBgLayer.frame = strongSelf.loginWindowView.bounds
            strongSelf.loginWindowView.center = center
        }
    }

    func createTabBtn(name: String, icon: String) -> UIButton {
        let btn = UIButton()
        btn.frame = CGRect(x: 0, y: 0, width: 70, height: 21)
        btn.backgroundColor = UIColor.init("3064B0")
        btn.layer.borderWidth = 0.5
        btn.layer.borderColor = UIColor.init("006EFF").cgColor
        btn.setImage(UIImage(named: icon), for: .normal)
        btn.imageView?.contentMode = .scaleAspectFit
        btn.setTitle(name, for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 10)
        let titleFrame = btn.titleLabel?.frame ?? CGRect.zero
        let imageFrame = btn.imageView?.frame ?? CGRect.zero
        let imageTagetFrame = CGRect(x: 5, y: 6, width: 10, height: 10)
        let titleTagetFrame = CGRect(x: 21.5, y: 3.5, width: 40, height: 14)
        let imgInsets = UIEdgeInsets(top: imageTagetFrame.origin.y - imageFrame.origin.y,
                                     left: imageTagetFrame.origin.x - imageFrame.origin.x,
                                     bottom: imageFrame.origin.y + imageFrame.size.height - imageTagetFrame.origin.y - imageTagetFrame.size.height,
                                     right: imageFrame.origin.x + imageFrame.size.width - imageTagetFrame.origin.x - imageTagetFrame.size.width)
        let txtInsets = UIEdgeInsets(top: titleTagetFrame.origin.y - titleFrame.origin.y,
                                     left: titleTagetFrame.origin.x - titleFrame.origin.x,
                                     bottom: titleFrame.origin.y + titleFrame.size.height - titleTagetFrame.origin.y - titleTagetFrame.size.height,
                                     right: titleFrame.origin.x + titleFrame.size.width - titleTagetFrame.origin.x - titleTagetFrame.size.width)
        btn.imageEdgeInsets = imgInsets
        btn.titleEdgeInsets = txtInsets
        return btn
    }

    @objc func onBeginEditing(_ view: UIView) {
        if keyboardTop != 0 {
            moveView(view, toTopKeyboard: keyboardTop)
        } else {
            currentInputView = view
        }
    }

    func moveView(_ view: UIView, toTopKeyboard keyboardTop: CGFloat) {
        let frame = view.convert(view.frame, to: self.view)
        let bottom = frame.origin.y + frame.size.height
        if bottom > keyboardTop {
            let offset = bottom - keyboardTop
            loginWindowView.transform = CGAffineTransform(translationX: 0, y: -offset)
        }
        currentInputView = nil
        self.keyboardTop = 0
    }

    @objc func keyboardWillShow(_ notification: NSNotification) {
        if let aValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardRect = aValue.cgRectValue
            let keyTop = keyboardRect.origin.y
            if let currentInputView = currentInputView {
                moveView(currentInputView, toTopKeyboard: keyTop)
            } else {
                keyboardTop = keyTop
            }
        }
        keyboardBgView.isHidden = false
    }

    @objc func keyboardWillHide(_ notification: NSNotification) {
        keyboardBgView.isHidden = true
        let code = isSimpleMode ? simpleCodeTxt.text : advanceCodeTxt.text
        if code!.count == 8 {
            startBtn.backgroundColor = UIColor.init("006EFF")
            startBtn.isEnabled = true
        } else {
            startBtn.backgroundColor = UIColor.init("006EFF20")
            startBtn.isEnabled = false
        }
        loginWindowView.transform = CGAffineTransform.identity
    }

    @objc func hiddenKeyboard(_ tapGesture: UITapGestureRecognizer) {
        loginWindowView.endEditing(true)
    }

    @objc func showToast(_ msg: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: nil, message: msg, preferredStyle: .alert)
            self.present(alert, animated: true, completion: nil)
            let duration = 2 // duration in seconds
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + .seconds(duration)) {
                alert.dismiss(animated: true, completion: nil)
            }
        }
    }

    @objc func startExperience() {
        loadingView.isHidden = false
        loadingView.processValue = 0;
        createGamePlayer()
    }

    func createExperienceSession(_ localSession: String) {
        var params = [String: Any]()
        userId = UUID().uuidString
        params["UserId"] = userId
        params["ClientSession"] = localSession
        params["RequestId"] = userId
        experienceCode = nil
        var tmpExperienceCode: String?
        var saveKey = "simple"
        
        if isSimpleMode {
            tmpExperienceCode = simpleCodeTxt.text
        } else {
            tmpExperienceCode = advanceCodeTxt.text
            
            if let fpsText = advanceFps.text, !fpsText.isEmpty {
                params["Fps"] = Int(fpsText)
            }
            if let gameId = advanceGameId.text, !gameId.isEmpty {
                params["GameId"] = gameId
            }
            if let userIdText = advanceUserId.text, !userIdText.isEmpty {
                userId = userIdText
                params["UserId"] = userIdText
            }
            if let hostUserId = advanceHostUserId.text, !hostUserId.isEmpty {
                params["HostUserId"] = hostUserId
                params["Role"] = advanceRole.selectedValue
            }
            if let resolution = advanceResolution.selectedValue, !resolution.isEmpty {
                params["Resolution"] = resolution
            }
            saveKey = "advance"
        }
        
        if let tmpExperienceCode = tmpExperienceCode {
            params["ExperienceCode"] = tmpExperienceCode
        }
        
        experienceCfg[saveKey] = params
        saveConfig(experienceCfg as! [AnyHashable : Any])
        TcrEnvTest.createAndStopSession("Start", params: params) { [weak self] (data, response, error) in
            guard let self = self else { return }
            
            if let error = error {
                self.showToast("申请机器失败:\(error.localizedDescription)")
                self.stopGame()
                return
            }
            
            guard let data = data, let jsonObj = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else {
                self.showToast("申请机器失败")
                self.stopGame()
                return
            }
            
            guard let code = jsonObj["Code"] as? NSNumber else {
                print("CreateExperienceSession bad code: \(jsonObj)")
                self.showToast("申请机器失败")
                self.stopGame()
                return
            }
            
            if code.intValue != 0 {
                print("CreateExperienceSession return code: \(jsonObj)")
                self.showToast("申请机器失败: \(jsonObj["Message"] ?? "")")
                self.stopGame()
                return
            }
            
            self.experienceCode = tmpExperienceCode
            if let serverSession = jsonObj["ServerSession"] as? String {
                DispatchQueue.main.async {
                    self.gotoGameplayVC(serverSession)
                }
            }
        }
    }

    func stopExperienceSession() {
        DispatchQueue.main.async { [weak self] in
            self?.loadingView.isHidden = true
        }
        
        guard ((experienceCode?.isEmpty) == nil) else {
            return
        }
        let messageDic: [String: Any] = ["ExperienceCode": experienceCode, "UserId": userId]
        TcrEnvTest.createAndStopSession("Stop", params: messageDic){ (data, response, error) in
            print("释放云端游戏资源")
        }
    }

    func gotoGameplayVC(_ remoteSession: String) {
        let subVC = TCRDemoGamePlayVC(play: session, remoteSession: remoteSession, loadingView: loadingView)
        addChild(subVC)
        subVC.view.frame = view.bounds
        view.insertSubview(subVC.view, belowSubview: loadingView)
        subVC.didMove(toParent: self)
        
        subVC.gameStopBlk = { [weak self] in
            self?.stopGame()
        }
        
        loadingView.processValue = 80
        // 这里可以释放对SDK的实例retain
        session = nil
    }

    
    func loadConfig() -> [AnyHashable : Any]? {
        let user = UserDefaults.standard
        var cfgDic = user.object(forKey: "TCRDEMO_EXPERIENCE_CFG") as? [AnyHashable : Any]
        if cfgDic == nil || !(cfgDic != nil) {
            cfgDic = [:]
        }
        return cfgDic
    }

    func saveConfig(_ cfgDic: [AnyHashable : Any]?) {
        let user = UserDefaults.standard
        user.set(cfgDic, forKey: "TCRDEMO_EXPERIENCE_CFG")
    }

    func createGamePlayer() {
        if session != nil {
            session.release()
            session = nil
        }
        
        session = TcrSession(params: ["local_audio": NSNumber(value: 0),"preferredCodec": "H264"], andDelegate: self)
    }

    func stopGame() {
        DispatchQueue.main.async(execute: { [self] in
            if (session != nil) {
                session.release()
                session = nil
            }
            loadingView.isHidden = true
            stopExperienceSession()
        })
    }

    func onEvent(_ event: TcrEvent, eventData: Any?) {
        if event == TcrEvent.STATE_INITED {
            DispatchQueue.main.async(execute: { [self] in
                createExperienceSession((eventData as? String)!)
            })
        }
    }

}

//
//  TCRDemoMultiSettingView.swift
//  TcrDemo
//
//  Created by xxhape on 2024/2/20.
//

import Foundation
import UIKit

protocol TCRDemoMultiSettingViewDelegate: AnyObject {
    func onApplySeatChange(userid: String, index: Int, role: String)
    func onSeatChange(userid: String, index: Int, role: String)
    func onSyscRoomInfo()
    func onsetMicMute(userid: String, enable: Bool)
}

class TCRDemoMultiSettingView: UIView ,UITextFieldDelegate {
    private var hostHeadLab: UILabel!
    private var guestHeadLab: UILabel!
    private var requestPlayerBtn: UIButton!
    private var requestViewerBtn: UIButton!
    private var changePlayerBtn: UIButton!
    private var changeViewerBtn: UIButton!
    private var syncRoomInfoBtn: UIButton!
    private var muteUserBtn: UIButton!
    private var userIDTF: UITextField!
    private var indexTF: UITextField!

    weak var delegate: UITextFieldDelegate?
    weak var multiSettingViewDelegate: TCRDemoMultiSettingViewDelegate?


    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor(white: 1, alpha: 0.7)
        self.initSubViews()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func createBtn(frame: CGRect, title: String) -> UIButton {
        let btn = UIButton(frame: frame)
        btn.backgroundColor = UIColor.clear
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        btn.setTitle(title, for: .normal)
        btn.setTitleColor(UIColor(white: 0, alpha: 1), for: .normal)
        btn.setTitleColor(UIColor.gray, for: .disabled)
        btn.setTitleColor(UIColor.blue, for: .selected)
        btn.addTarget(self, action: #selector(controlBtnClick(_:)), for: .touchUpInside)
        return btn
    }
    
    private func createLab(frame: CGRect, title: String) -> UILabel {
        let lab = UILabel(frame: frame)
        lab.backgroundColor = UIColor.clear
        lab.font = UIFont.systemFont(ofSize: 15)
        lab.textColor = UIColor.black
        lab.textAlignment = .left
        lab.text = title
        return lab
    }

    private func initSubViews() {
        let selfWidth = self.frame.size.width
        let selfHeight = self.frame.size.height
        // TODO 监测自适应全面屏与非全面屏
        let left: CGFloat = 48 // window.safeAreaInsets.top

        self.userIDTF = UITextField(frame: CGRect(x: left + 10, y: 60, width: 70, height: 25))
        self.userIDTF.borderStyle = .roundedRect
        self.userIDTF.placeholder = "输入id"
        self.userIDTF.delegate = self.delegate
        self.indexTF = UITextField(frame: CGRect(x: left + 180, y: 60, width: 70, height: 25))
        self.indexTF.borderStyle = .roundedRect
        self.indexTF.placeholder = "输入坐席"
        self.indexTF.delegate = self.delegate

        self.hostHeadLab = createLab(frame: CGRect(x: left + 10, y: 100, width: 70, height: 25), title: "我是房主:")
        self.changePlayerBtn = createBtn(frame: CGRect(x: left + 110, y: 100, width: 90, height: 25), title: "切换为玩家")
        self.changeViewerBtn = createBtn(frame: CGRect(x: left + 210, y: 100, width: 90, height: 25), title: "切换为观众")

        self.guestHeadLab = createLab(frame: CGRect(x: left + 10, y: 140, width: 70, height: 25), title: "我是访客:")
        self.requestPlayerBtn = createBtn(frame: CGRect(x: left + 110, y: 140, width: 90, height: 25), title: "申请为玩家")
        self.requestViewerBtn = createBtn(frame: CGRect(x: left + 210, y: 140, width: 90, height: 25), title: "申请为观众")

        self.muteUserBtn = createBtn(frame: CGRect(x: left + 10, y: 180, width: 70, height: 25), title: "静音玩家")
        self.syncRoomInfoBtn = createBtn(frame: CGRect(x: left + 110, y: 180, width: 130, height: 25), title: "刷新房间信息")

        addSubview(self.hostHeadLab)
        addSubview(self.guestHeadLab)
        addSubview(self.requestPlayerBtn)
        addSubview(self.requestViewerBtn)
        addSubview(self.changePlayerBtn)
        addSubview(self.changeViewerBtn)
        addSubview(self.muteUserBtn)
        addSubview(self.userIDTF)
        addSubview(self.indexTF)
        addSubview(self.syncRoomInfoBtn)
    }

    @objc private func controlBtnClick(_ sender: Any) {
        guard let button = sender as? UIButton else { return }

        if button == syncRoomInfoBtn {
            multiSettingViewDelegate?.onSyscRoomInfo()
            return
        }

        guard let userID = userIDTF.text, let indexS = indexTF.text else { return }
        guard let index = Int(indexS) else { return }

        if button == changePlayerBtn {
            multiSettingViewDelegate?.onSeatChange(userid: userID, index: index, role: "player")
        } else if button == changeViewerBtn {
            multiSettingViewDelegate?.onSeatChange(userid: userID, index: index, role: "viewer")
        } else if button == requestPlayerBtn {
            multiSettingViewDelegate?.onApplySeatChange(userid: userID, index: index, role: "player")
        } else if button == requestViewerBtn {
            multiSettingViewDelegate?.onApplySeatChange(userid: userID, index: index, role: "viewer")
        } else if button == muteUserBtn {
            var titleText = "静音玩家"
            var enable = true
            if muteUserBtn.titleLabel?.text == titleText {
                titleText = "解禁玩家"
                enable = false
            }
            multiSettingViewDelegate?.onsetMicMute(userid: userID, enable: enable)
        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

}

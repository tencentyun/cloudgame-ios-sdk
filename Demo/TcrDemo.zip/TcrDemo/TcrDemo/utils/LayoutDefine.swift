

import Foundation
import UIKit

public let ScreenWidth = UIScreen.main.bounds.width
public let ScreenHeight = UIScreen.main.bounds.height

public let kDeviceIsIphoneX : Bool = {
    if UIDevice.current.userInterfaceIdiom == .pad {
        return false
    }
    let size = UIScreen.main.bounds.size
    let notchValue = Int(size.width/size.height*100)
    if notchValue == 216 || notchValue == 46 {
        return true
    }
    return false
}()

public let kDeviceSafeTopHeight : CGFloat = {
    if kDeviceIsIphoneX {
        return 44
    }
    else {
        return 20
    }
}()

public let kDeviceSafeBottomHeight : CGFloat = {
    if kDeviceIsIphoneX {
        return 34
    }
    else {
        return 0
    }
}()

public let kDeviceOnePixel : CGFloat = {
    return 1 / UIScreen.main.scale
}()

public func convertPixel(w:CGFloat) -> CGFloat {
    return w/375.0*ScreenWidth
}

public func convertPixel(h:CGFloat) -> CGFloat {
    return h/812.0*ScreenHeight
}

extension UIView {
    func setLeft(_ newLeft:CGFloat) {
        var newFrame = self.frame
        newFrame.origin.x = newLeft
        self.frame = newFrame
    }
    
    func setTop(_ newTop:CGFloat) {
        var newFrame = self.frame
        newFrame.origin.y = newTop
        self.frame = newFrame
    }

    func setWidth(_ newWidth:CGFloat) {
        var newFrame = self.frame
        newFrame.size.width = newWidth
        self.frame = newFrame
    }

    func setHeight(_ newHeight:CGFloat) {
        var newFrame = self.frame
        newFrame.size.height = newHeight
        self.frame = newFrame
    }
}

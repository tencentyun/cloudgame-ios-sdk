//
//  TCRGamePlayVC.swift
//  TcrDemo
//
//  Created by xxhape on 2024/2/20.
//

import Foundation

typealias tGameStopBlk = () -> Void

class TCRDemoGamePlayVC : UIViewController ,TcrSessionObserver, TCRDemoTextFieldDelegate, CustomDataChannelObserver, TCRDemoSettingViewDelegate, TCRLogDelegate,TcrRenderViewObserver, TCRDemoMultiSettingViewDelegate {

    var gameStopBlk : tGameStopBlk?
    var remoteSession: String?
    var session: TcrSession?
    var renderView: TcrRenderView?
    var videoStreamSize: CGSize = .zero
    var videoRenderFrame: CGRect = .zero

    var settingBtn: UIButton?
    var multiSettingBtn: UIButton?
    var settingView: TCRDemoSettingView?
    var multiSettingView: TCRDemoMultiSettingView?
    var hiddenText: TCRDemoTextField?
    var keyboardBgView: UIView?
    var debugLab: UILabel?
    var debugLabTimer: Timer?
    var reconnect: Bool = false
    var usingGamepad: Bool = false
    var usingCursor: Bool = false
    var customChannel: CustomDataChannel?
    var loadingView: TCRDemoLoadingView?
    var imageView: UIImageView?
    var pcTouchView: PcTouchView?
    var mobileTouchView: MobileTouchView?
    var isFirstRender: Bool = false
    var gamepad: TCRVKeyGamepad?
    var isMobile: Bool = false
    
    
    convenience init(play: TcrSession, remoteSession: String) {
        self.init(play: play, remoteSession: remoteSession, loadingView: nil)
    }
    
    init(play: TcrSession, remoteSession: String, loadingView: UIView?) {
        super.init(nibName: nil, bundle: nil)
        self.session = play
        self.isFirstRender = false
        self.remoteSession = remoteSession
        self.loadingView = loadingView as? TCRDemoLoadingView
        self.session?.setTcrSessionObserver(self)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initGamePlayView()
        initSettingView()
        initMultiSettingView()
        initVirtualKeyboard()
        initDebugView()
        
        // 图层的层级要注意，影响点击事件的响应
        view.addSubview(hiddenText!)
        renderView = TcrRenderView(frame: view.frame)
        // SDK游戏视图
        view.addSubview(renderView!)
        // Demo业务视图
        view.addSubview(settingView!)
        view.addSubview(settingBtn!)
        view.addSubview(multiSettingView!)
        view.addSubview(multiSettingBtn!)
        view.addSubview(keyboardBgView!)
        view.addSubview(debugLab!)
        resetVideoView(with: CGSize(width: 1280, height: 720))
        TcrSdkInstance.setLogger(self, withMinLevel: .info)
        session?.setRenderView(renderView)
        renderView!.setTcrRenderViewObserver(self)
        isMobile = false  // 云端应用为手机应用还是windows应用
        initControlViews()

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        
        if session != nil && remoteSession != nil {
            session?.start(remoteSession!)
        }
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        NotificationCenter.default.removeObserver(self)
    }

    func initGamePlayView() {
        renderView?.enablePinch = true
    }

    func resetVideoOrientation(_ orientation: UIInterfaceOrientation) {
        // implementation goes here
    }

    func resetVideoView(with videoSize: CGSize) {
        videoStreamSize = videoSize
        let vcOrient = UIApplication.shared.statusBarOrientation
        var newWidth: CGFloat = 0
        var newHeight: CGFloat = 0
        
        newWidth = view.frame.size.width
        newHeight = view.frame.size.height
        newHeight -= view.safeAreaInsets.top + view.safeAreaInsets.bottom
        if isMobile && vcOrient == .landscapeRight {
            // 手游的视频分辨率只会是 宽 < 高，当手机横屏显示时，需要将videoView画面逆时钟旋转90度。
            newWidth = view.frame.size.height
            newHeight = view.frame.size.width
            newHeight -= view.safeAreaInsets.left + view.safeAreaInsets.right
        }
        
        // 游戏画面强制横屏、长边对齐，短边留白 可考虑在viewSafeAreaInsetsDidChange之后再创建subview
        newWidth -= view.safeAreaInsets.left + view.safeAreaInsets.right
        if newWidth / newHeight < videoSize.width / videoSize.height {
            newHeight = floor(newWidth * videoSize.height / videoSize.width)
        } else {
            newWidth = floor(newHeight * videoSize.width / videoSize.height)
        }
        
        videoRenderFrame = CGRect(x: (view.frame.size.width - newWidth) / 2, y: (view.frame.size.height - newHeight) / 2, width: newWidth, height: newHeight)
        renderView!.frame = videoRenderFrame
        if isMobile {
            mobileTouchView?.frame = renderView!.bounds
        } else {
            pcTouchView?.frame = renderView!.bounds
        }
        
        if isMobile && UIApplication.shared.statusBarOrientation == .landscapeRight {
            renderView!.transform = CGAffineTransform(rotationAngle: -CGFloat.pi / 2)
        }
    }
    
    func initVirtualKeyboard() {
        hiddenText = TCRDemoTextField(frame: CGRect(x: 10, y: 10, width: 1, height: 1))
        hiddenText!.keyCodedelegate = self
        
        keyboardBgView = UIView(frame: view.bounds)
        keyboardBgView?.backgroundColor = .clear
        keyboardBgView?.isUserInteractionEnabled = true
        keyboardBgView?.isHidden = true
        
        let singleClick = UITapGestureRecognizer(target: self, action: #selector(singleClickAction(_:)))
        keyboardBgView?.addGestureRecognizer(singleClick)
    }

    func initControlViews() {
        // 触摸转鼠标: 创建一个与renderView大小位置相同的pcTouchView
        pcTouchView = PcTouchView(frame: CGRect(x: 0, y: 0, width: videoRenderFrame.size.width, height: videoRenderFrame.size.height), session: session)
        pcTouchView?.isHidden = true

        // 触摸转windows触摸: 创建一个与renderView大小位置相同的mobileTouchView
        mobileTouchView = MobileTouchView(frame: CGRect(x: 0, y: 0, width: videoRenderFrame.size.width, height: videoRenderFrame.size.height), session: session!)
        mobileTouchView?.isHidden = true

        // 虚拟按键视图加载
        gamepad = TCRVKeyGamepad(frame: CGRect(x: 0, y: 0, width: videoRenderFrame.size.width, height: videoRenderFrame.size.height), session: session)
        gamepad?.show(readJsonFromFile("lol"))
        gamepad?.isHidden = true
        renderView!.addSubview(pcTouchView!)
        renderView!.addSubview(mobileTouchView!)
        renderView!.addSubview(gamepad!)

    }

    func initSettingView() {
        // 调试视图的初始化
        let btn1 = UIButton(frame: CGRect(x: view.frame.size.width - 50, y: 30, width: 30, height: 30))
        btn1.backgroundColor = .clear
        btn1.setImage(UIImage(named: "setting"), for: .normal)
        btn1.addTarget(self, action: #selector(settingBtnClick(_:)), for: .touchUpInside)

        settingView = TCRDemoSettingView(frame: view.bounds)
        settingView!.delegate = self
        settingView!.isHidden = true

        settingBtn = btn1
        settingBtn!.isHidden = true
    }

    func initMultiSettingView() {
        let btn1 = UIButton(frame: CGRect(x: 50, y: 30, width: 30, height: 30))
        btn1.backgroundColor = .clear
        btn1.setImage(UIImage(named: "login_radio_unselected"), for: .normal)
        btn1.addTarget(self, action: #selector(multiSesstingBtnClick(_:)), for: .touchUpInside)

        multiSettingView = TCRDemoMultiSettingView(frame: view.bounds)
        multiSettingView!.multiSettingViewDelegate = self
        multiSettingView!.isHidden = true

        multiSettingBtn = btn1
        multiSettingBtn!.isHidden = true
    }

    func initDebugView() {
        let lab = UILabel(frame: CGRect(x: 30, y: videoRenderFrame.origin.y, width: 350, height: 15))
        lab.backgroundColor = UIColor(white: 0.2, alpha: 0.3)
        lab.font = UIFont.systemFont(ofSize: 10)
        lab.textColor = .white
        lab.textAlignment = .left
        lab.isHidden = true
        debugLab = lab
    }
    
    func enableUpdateDebugInfo(_ isEnable: Bool) {
        debugLabTimer?.invalidate()
        debugLabTimer = nil
        if !isEnable {
            return
        }
        debugLabTimer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(updateDebugInfo), userInfo: nil, repeats: true)
    }

    @objc func updateDebugInfo(_ info: [AnyHashable: Any]) {
        let rtt = info["RTT"] as? NSNumber
        let fps = info["FPS"] as? NSNumber
        let videoDelay = info["VideoDelay"] as? NSNumber
        let videoNack = info["VideoPacketNack"] as? NSNumber
        let videoBitrateKbps = info["VideoBitrateRecvKb"] as? NSNumber
        let audioDelay = info["AudioDelay"] as? NSNumber
        DispatchQueue.main.async {
            self.debugLab?.text = String(format: "rtt:%@, fps:%@, v_delay:%@, v_nack:%@, a_delay:%@ v_bitrate:%@kbps", rtt?.stringValue ?? "-", fps?.stringValue ?? "-", videoDelay?.stringValue ?? "-", videoNack?.stringValue ?? "-", audioDelay?.stringValue ?? "-", videoBitrateKbps?.stringValue ?? "-")
            self.settingView!.setAllDebugInfo(info)
        }
    }

    func readJsonFromFile(_ fileName: String) -> String? {
        guard let path = Bundle.main.path(forResource: fileName, ofType: "cfg") else {
            return nil
        }
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: path)) else {
            return nil
        }
        return String(data: data, encoding: .utf8)
    }

    func showToast(_ msg: String) {
        let alert = UIAlertController(title: nil, message: msg, preferredStyle: .alert)
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }
        let duration = 2  // duration in seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(duration)) {
            alert.dismiss(animated: true, completion: nil)
        }
    }
    
    // MARK: - TCGDemoTextFieldDelegate
    func onClickKey(_ keyCode: Int) {
        print("onClickKey:\(keyCode)")
        let shiftKeycode: Int32 = 16
        if keyCode >= 65 && keyCode <= 90 {
            let newKeycode = keyCode - 65 + Int(UnicodeScalar("A").value)
            session?.getKeyboard().onKeyboard(Int(shiftKeycode), down: true)
            session?.getKeyboard().onKeyboard(newKeycode, down: true)
            session?.getKeyboard().onKeyboard(newKeycode, down: false)
            session?.getKeyboard().onKeyboard(Int(shiftKeycode), down: false)
        }
        if keyCode >= 97 && keyCode <= 122 {
            let newKeycode = Int(keyCode) - 97 + Int(UnicodeScalar("A").value)
            session?.getKeyboard().onKeyboard(newKeycode, down: true)
            session?.getKeyboard().onKeyboard(newKeycode, down: false)
        }
        if keyCode >= 48 && keyCode <= 57 {
            let newKeycode = keyCode - 48 + Int(UnicodeScalar("0").value)
            session?.getKeyboard().onKeyboard(newKeycode, down: true)
            session?.getKeyboard().onKeyboard(newKeycode, down: false)
        }
        if keyCode == 8 {  // 删除按键
            session?.getKeyboard().onKeyboard(keyCode, down: true)
            session?.getKeyboard().onKeyboard(keyCode, down: false)
        }
    }

    @objc func singleClickAction(_ tapGesture: UITapGestureRecognizer) {
        if tapGesture.state == .recognized {
            hiddenText!.resignFirstResponder()
        }
    }

    @objc func keyboardWillShow(_ notification: Notification) {
        keyboardBgView?.isHidden = false
    }

    @objc func keyboardWillHide(_ notification: Notification) {
        keyboardBgView?.isHidden = true
    }
    
    // MARK: - TCGDemoSettingViewDelegate
    @objc func settingBtnClick(_ sender: Any) {
        settingView!.isHidden = !settingView!.isHidden
    }

    @objc func multiSesstingBtnClick(_ sender: Any) {
        multiSettingView!.isHidden = !multiSettingView!.isHidden
    }

    func stopGame() {
        DispatchQueue.main.async {
            self.debugLabTimer?.invalidate()
            self.renderView?.removeFromSuperview()
            self.session?.release()
            if let gameStopBlk = self.gameStopBlk {
                gameStopBlk()
            }
            self.willMove(toParent: self.parent)
            self.view.removeFromSuperview()
            self.removeFromParent()
        }
    }
    
    func onSetBitrate(_ level: Int) {
        var max = 2;
        var min = 1;
        var fps = 30;
        switch (level) {
            case 0:
                min = 1 * 1024;
                max = 2 * 1024;
                fps = 30;
                break;
            case 1:
                min = 3 * 1024;
                max = 4 * 1024;
                fps = 45;
                break;
            case 2:
                min = 7 * 1024;
                max = 8 * 1024;
                fps = 60;
            default:
                break;
        }
        self.session?.setRemoteVideoProfile(Int32(fps), minBitrate: Int32(min), maxBitrate: Int32(max))
    }

    // MARK: 云应用交互测试
    func restartGame() {
        session?.restartCloudApp()
    }

    func pasteText() {
        session?.pasteText("123")
    }

    func modifyRES() {
        session?.setRemoteDesktopResolution(1080, height: 1920)
    }
    
    func openKeyboard(_ isOpen: Bool) {
        if isOpen {
            pcTouchView?.isHidden = false
            pcTouchView?.setCursorTouchMode(.relativeTouch)
            pcTouchView?.setCursorImage(UIImage(named: "default_cursor"), andRemoteFrame: CGRect(x: 0, y: 0, width: 32, height: 32))
            pcTouchView?.setCursorIsShow(true)
        } else {
            pcTouchView?.isHidden = true
        }
        usingCursor = isOpen
    }

    func clearAllKeys() {
        session?.getKeyboard().resetKeyboard()
    }

    func checkCapsLock() {
        session?.getKeyboard().checkCapsLock({ retCode in
            if retCode < 0 {
                print("check capslock failed:\(retCode)")
                return
            }
            self.showToast(retCode == 1 ? "云端打开大写锁定" : "云端关闭大写锁定")
        })
    }

    // MARK: - 数据通道测试
    func onCreateDataChannel() {
        customChannel = session?.createCustomDataChannel(6665, observer: self)
    }

    func onDataChannelSend() {
        let value = 123
        let number = NSNumber(value: value)
        guard let data = try? NSKeyedArchiver.archivedData(withRootObject: number, requiringSecureCoding: true) else {
            return
        }
        customChannel?.send(data)
    }

    // MARK: - 触摸转鼠标设置项
    func onSetCursorTouchMode(_ mode: Int) {
        pcTouchView?.setCursorTouchMode(TCRMouseCursorTouchMode(rawValue: Int(mode)) ?? .relativeTouch)
    }

    func onSetCursorSensitive(_ sensitive: CGFloat) {
        pcTouchView?.setCursorSensitive(sensitive)
    }

    func onSetCursorClickType(_ isLeft: Bool) {
        pcTouchView?.setClickTypeIsLeft(isLeft)
    }
    
    // MARK: - 音视频传输测试
    func onSetVolume(_ volume: CGFloat) {
        session?.setRemoteAudioProfile(Float(volume))
    }

    func pauseResumeGame(_ doPause: Bool) {
        doPause ? session?.pauseStreaming() : session?.resumeStreaming()
    }

    func onEnableLocalAudio(_ enable: Bool) {
        session?.setEnableLocalAudio(enable)
    }

    func onRotateView() {
        let oldRect = renderView!.frame
        let scaleTrans = CGAffineTransform(scaleX: oldRect.size.height / oldRect.size.width, y: oldRect.size.width / oldRect.size.height)
        let rotateTrans = self.renderView?.transform.rotated(by: -CGFloat.pi / 2)
        print("onRotateView self.gamePlayer.videoView.frame:\(self.renderView!.frame)")
        self.renderView!.transform = rotateTrans!
    }

    func openTouchView(_ isOpen: Bool) {
        mobileTouchView?.isHidden = !isOpen
    }
    
    func openPadView(_ isOpen: Bool) {
        self.gamepad?.isHidden = isOpen
    }

    // MARK: - TCRLogDelegate
    func log(with logLevel: TCRLogLevel, log: String?) {
        print("[TCRSDK] \(logLevel.rawValue), \(String(describing: log))")
    }
    // MARK: - TCRSessionObserver
    func onEvent(_ event: TcrEvent, eventData: Any?) {
        var info: [AnyHashable: Any]?
        var array: [Any]?
        var rect: CGRect
        switch event {
        case .STATE_CONNECTED:
            print("requestId = \(session?.getRequestId() ?? "")")
            self.session?.getGamepad().connect()
            showToast("连接成功")
        case .STATE_RECONNECTING:
            showToast("重连中")
        case .STATE_CLOSED:
            showToast("会话关闭")
        case .VIDEO_STREAM_CONFIG_CHANGED:
            print("ApiTest 分辨率变化:\(eventData as? String ?? "")")
            info = eventData as? [AnyHashable: Any]
            let width = info?["width"] as? CGFloat ?? 0
            let height = info?["height"] as? CGFloat ?? 0
            resetVideoView(with: CGSize(width: width, height: height))
        case .SCREEN_CONFIG_CHANGE:
            print("ApiTest 横竖屏变化:\(eventData as? String ?? "")")
            resetVideoOrientation(eventData as? UIInterfaceOrientation ?? .unknown)
        case .MULTI_USER_SEAT_INFO:
            print("ApiTest 房间信息变化:\(eventData as? String ?? "")")
        case .MULTI_USER_ROLE_APPLY:
            print("ApiTest 收到坐席请求:\(eventData as? String ?? "")")
        case .CURSOR_IMAGE_INFO:
            info = eventData as? [AnyHashable: Any]
            array = info?["imageFrame"] as? [Any]
            rect = CGRect(x: array?[0] as? CGFloat ?? 0, y: array?[1] as? CGFloat ?? 0, width: array?[2] as? CGFloat ?? 0, height: array?[3] as? CGFloat ?? 0)
            pcTouchView!.setCursorImage(info?["image"] as? UIImage, andRemoteFrame: rect)
        case .CLIENT_STATS:
            info = eventData as? [AnyHashable: Any]
            updateDebugInfo(eventData as! [AnyHashable : Any])
        case .INPUT_STATE_CHANGE:
            info = eventData as? [AnyHashable: Any]
            if info?["field_type"] as? String == "normal_input" {
                checkKBOpen()
            }
        case .GAME_START_COMPLETE:
            print("ApiTest 游戏拉起:\(eventData as? String ?? "")")
        default:
            break
        }
    }

    func checkKBOpen() {
        DispatchQueue.main.async {
            if self.hiddenText!.canBecomeFirstResponder {
                self.hiddenText!.becomeFirstResponder()
            } else {
                print("键盘拉起失败")
            }
        }
    }
    
    // MARK: - TCGCustomTransChannelDelegate
    func onConnected(_ port: Int) {
        print("onConnSuccessAtRemotePort \(port)")
    }

    func onError(_ port: Int, code: Int, message msg: String) {
        print("onError:port:\(port) code:\(code) msg:\(msg )")
    }

    func onMessage(_ port: Int, buffer: Data) {
        let msg = String(data: buffer , encoding: .utf8)
        print("onReceiveData:\(msg ?? "") port:\(port)")
    }

    // MARK: - TcrRenderViewObserver
    func onFirstFrameRendered() {
        print("首帧回调通知")
        DispatchQueue.main.async { [weak self] in
            self?.settingBtn?.isHidden = false
            self?.multiSettingBtn?.isHidden = false
            self?.debugLab?.isHidden = false
            self?.renderView?.enablePinch=true
            self?.loadingView?.processValue = 100
        }
    }


    // MARK: - 多人互动
    func onApplySeatChange(userid: String, index: Int, role: String) {
        session?.requestChangeSeat(userid, targetRole: role, targetPlayerIndex: Int32(index)) { retCode in
            if retCode < 0 {
                print("check capslock failed:\(retCode)")
                return
            }
            print("申请席位结果:\(retCode)")
        }
    }

    func onSeatChange(userid: String, index: Int, role: String) {
        session?.changeSeat(userid, targetRole: role, targetPlayerIndex: Int32(index)) { retCode in
            if retCode < 0 {
                print("check capslock failed:\(retCode)")
                return
            }
            print("切换席位结果:\(retCode)")
        }
    }

    func onSyscRoomInfo() {
        session?.syncRoomInfo()
    }

    func onsetMicMute(userid: String, enable index: Bool) {
        session?.setMicMute(userid, micStatus: 0) { retCode in
            if retCode < 0 {
                print("check capslock failed:\(retCode)")
                return
            }
            print("禁言结果:\(retCode)")
        }
    }
}

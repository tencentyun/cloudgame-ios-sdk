//
//  TCRDemoTextField.swift
//  TcrDemo
//
//  Created by xxhape on 2024/2/20.
//

import UIKit

protocol TCRDemoTextFieldDelegate: AnyObject {
    func onClickKey(_ keyCode: Int)
}

class TCRDemoTextField: UITextField, UITextFieldDelegate {
    weak var keyCodedelegate: TCRDemoTextFieldDelegate?

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        self.textColor = UIColor.clear
        self.keyboardType = .asciiCapable
        self.tintColor = UIColor.clear
        self.returnKeyType = .done
        self.autocorrectionType = .no
        self.delegate = self
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func deleteBackward() {
        super.deleteBackward()
        print("delete")
        if let delegate = self.keyCodedelegate {
            delegate.onClickKey(8)
        }
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        print(string)

        if string.count > 0, let delegate = self.keyCodedelegate {
            let keyCode = Int(string.unicodeScalars.first!.value)
            delegate.onClickKey(keyCode)
        }

        return false
    }
}

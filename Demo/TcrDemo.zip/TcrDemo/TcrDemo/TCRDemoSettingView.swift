//
//  TCRDemoSettingView.swift
//  TcrDemo
//
//  Created by xxhape on 2024/2/20.
//

import Foundation
import UIKit

protocol TCRDemoSettingViewDelegate: AnyObject {
    func pasteText()
    func restartGame()
    func modifyRES()
    func onSetVolume(_ volume: CGFloat)
    func onEnableLocalAudio(_ enable: Bool)
    func pauseResumeGame(_ doPause: Bool)
    func onCreateDataChannel()
    func onDataChannelSend()
    func openKeyboard(_ isOpen: Bool)
    func onSetBitrate(_ level:Int)
    func onSetCursorTouchMode(_ mode: Int)
    func onSetCursorSensitive(_ sensitive: CGFloat)
    func onSetCursorClickType(_ isLeft: Bool)
    func clearAllKeys()
    func checkCapsLock()
    func stopGame()
    func onRotateView()
    func openTouchView(_ isOpen: Bool)
    func openPadView(_ isOpen: Bool)
}

class TCRDemoSettingView: UIView {
    var enableKeyboardBtn: UIButton?
    var cursorBtn1: UIButton?
    var cursorBtn2: UIButton?
    var cursorBtn3: UIButton?
    var cursorBtn4: UIButton?
    var cursorSensitiveLab: UILabel?
    var cursorSlider: UISlider?
    var volumeLab: UILabel?
    var volumeSlider: UISlider?
    var restartBtn: UIButton?
    var pauseBtn: UIButton?
    var stopGameBtn: UIButton?
    var clearKeyBtn: UIButton?
    var capsLockBtn: UIButton?
    var rotateViewBtn: UIButton?
    var touchViewBtn: UIButton?
    var padViewBtn: UIButton?
    var enableLocalAudioBtn: UIButton?
    var patseTextBtn: UIButton?
    var changeResBtn: UIButton?
    var createDCBtn: UIButton?
    var sendDCDataBtn: UIButton?
    var bitrateBtn: UIButton?
    var allInfo: UILabel?
    var bitrateLevel: Array<Any>?
    var bitrateLevelIndex: Int?
    weak var delegate: TCRDemoSettingViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor(white: 1, alpha: 0.7)
        self.initSubViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createBtnFrame(frame: CGRect, title: String) -> UIButton {
        let btn = UIButton(frame: frame)
        btn.backgroundColor = UIColor.clear
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        btn.setTitle(title, for: .normal)
        btn.setTitleColor(UIColor(white: 0, alpha: 1), for: .normal)
        btn.setTitleColor(UIColor.gray, for: .disabled)
        btn.setTitleColor(UIColor.blue, for: .selected)
        btn.addTarget(self, action: #selector(controlBtnClick(sender:)), for: .touchUpInside)
        return btn
    }
    
    @objc func controlBtnClick(sender: UIButton) {
        if sender === self.enableKeyboardBtn {
            if self.enableKeyboardBtn?.titleLabel?.text == "使用键鼠" {
                self.enableKeyboardBtn?.setTitle("禁用键鼠", for: .normal)
                self.delegate?.openKeyboard(true)
                self.cursorBtn1?.isEnabled = true
                self.cursorBtn2?.isEnabled = true
                self.cursorBtn2?.isSelected = true
                self.cursorBtn3?.isEnabled = true
                self.cursorBtn4?.isEnabled = true
                self.cursorSlider?.isEnabled = true
            } else {
                self.enableKeyboardBtn?.setTitle("使用键鼠", for: .normal)
                self.delegate?.openKeyboard(false)
                self.cursorBtn1?.isEnabled = false
                self.cursorBtn2?.isEnabled = false
                self.cursorBtn3?.isEnabled = false
                self.cursorBtn4?.isEnabled = false
                self.cursorBtn1?.isSelected = false
                self.cursorBtn2?.isSelected = false
                self.cursorBtn3?.isSelected = false
                self.cursorSlider?.isEnabled = false
            }
        } else if sender === self.stopGameBtn {
            self.isHidden = true
            self.delegate?.stopGame()
        } else if (sender == self.bitrateBtn) {
            self.bitrateLevelIndex = self.bitrateLevelIndex! >= 2 ? 0 : (self.bitrateLevelIndex! + 1)
            self.bitrateBtn!.setTitle(self.bitrateLevel?[self.bitrateLevelIndex!] as! String, for: .normal)
            self.delegate?.onSetBitrate(self.bitrateLevelIndex!)
        } else if sender === self.restartBtn {
            self.delegate?.restartGame()
        } else if sender === self.clearKeyBtn {
            self.delegate?.clearAllKeys()
        } else if sender === self.cursorBtn1 {
            self.cursorBtn1?.isSelected = true
            self.cursorBtn2?.isSelected = false
            self.cursorBtn3?.isSelected = false
            self.cursorBtn4?.isEnabled = false
            self.delegate?.onSetCursorTouchMode(0)
        } else if sender === self.cursorBtn2 {
            self.cursorBtn1?.isSelected = false
            self.cursorBtn2?.isSelected = true
            self.cursorBtn3?.isSelected = false
            self.cursorBtn4?.isEnabled = true
            self.delegate?.onSetCursorTouchMode(1)
        } else if sender === self.cursorBtn3 {
            self.cursorBtn1?.isSelected = false
            self.cursorBtn2?.isSelected = false
            self.cursorBtn3?.isSelected = true
            self.cursorBtn4?.isEnabled = true
            self.delegate?.onSetCursorTouchMode(2)
        } else if sender === self.cursorBtn4 {
            let titleText = "切成左键"
            var isLeft = true
            if self.cursorBtn4?.titleLabel?.text == titleText {
                self.cursorBtn4?.setTitle("切成右键", for: .normal)
            } else {
                self.cursorBtn4?.setTitle(titleText, for: .normal)
                isLeft = false
            }
            self.delegate?.onSetCursorClickType(isLeft)
        } else if sender === self.pauseBtn {
            var titleText = "恢复游戏"
            var isPause = true
            if self.pauseBtn?.titleLabel?.text == titleText {
                titleText = "挂起游戏"
                isPause = false
            }
            self.pauseBtn?.setTitle(titleText, for: .normal)
            self.delegate?.pauseResumeGame(isPause)
        } else if sender === self.enableLocalAudioBtn {
            var titleText = "关麦克风"
            var enable = false
            if self.enableLocalAudioBtn?.titleLabel?.text == titleText {
                titleText = "开麦克风"
                enable = true
            }
            self.enableLocalAudioBtn?.setTitle(titleText, for: .normal)
            self.delegate?.onEnableLocalAudio(enable)
        } else if sender === self.capsLockBtn {
            self.delegate?.checkCapsLock()
        } else if sender === self.rotateViewBtn {
            self.delegate?.onRotateView()
        } else if sender === self.changeResBtn {
            self.delegate?.modifyRES()
        } else if sender === self.patseTextBtn {
            self.delegate?.pasteText()
        } else if sender === self.createDCBtn {
            self.delegate?.onCreateDataChannel()
        } else if sender === self.sendDCDataBtn {
            self.delegate?.onDataChannelSend()
        } else if sender === self.touchViewBtn {
            var titleText = "使用触屏"
            var isOpen = false
            if self.touchViewBtn?.titleLabel?.text == titleText {
                titleText = "禁用触屏"
                isOpen = true
            }
            self.touchViewBtn?.setTitle(titleText, for: .normal)
            self.delegate?.openTouchView(isOpen)
        } else if sender === self.padViewBtn {
            var titleText1 = "按键开"
            var isOpen1 = false
            if self.touchViewBtn?.titleLabel?.text == titleText1 {
                titleText1 = "按键关"
                isOpen1 = true
            }
            self.padViewBtn?.setTitle(titleText1, for: .normal)
            self.delegate?.openPadView(isOpen1)
        }
    }
    
    @objc func sliderValueChanged(sender: Any) {
        guard let slider = sender as? UISlider else {
            return
        }
        if slider == self.cursorSlider {
            self.cursorSensitiveLab?.text = String(format: "鼠标滑动灵敏度:%.1f", slider.value)
            self.delegate?.onSetCursorSensitive(CGFloat(slider.value))
        } else if slider == self.volumeSlider {
            self.volumeLab?.text = String(format: "音量增益系数:%.1f", slider.value)
            self.delegate?.onSetVolume(CGFloat(slider.value))
        }
    }
    
    func initSubViews() {
        let selfWidth = self.frame.size.width
        let selfHeight = self.frame.size.height
        let left: CGFloat = 48
        
        enableKeyboardBtn = createBtnFrame(frame: CGRect(x: left + 10, y: 60, width: 70, height: 25), title: "使用键鼠")
        cursorBtn1 = createBtnFrame(frame: CGRect(x: left + 90, y: 60, width: 70, height: 25), title: "触控")
        cursorBtn2 = createBtnFrame(frame: CGRect(x: left + 180, y: 60, width: 70, height: 25), title: "滑鼠点击")
        cursorBtn3 = createBtnFrame(frame: CGRect(x: left + 270, y: 60, width: 70, height: 25), title: "滑屏")
        cursorBtn4 = createBtnFrame(frame: CGRect(x: left + 360, y: 60, width: 70, height: 25), title: "切成右键")
        cursorBtn1?.isEnabled = false
        cursorBtn2?.isEnabled = false
        cursorBtn3?.isEnabled = false
        cursorBtn4?.isEnabled = false
        
        let cursorlab = UILabel(frame: CGRect(x: left + 10, y: 100, width: 150, height: 25))
        cursorlab.backgroundColor = UIColor.clear
        cursorlab.font = UIFont.systemFont(ofSize: 15)
        cursorlab.textColor = UIColor.black
        cursorlab.text = "鼠标滑动灵敏度:1.0"
        cursorlab.textAlignment = .left
        let cursorSlider = UISlider(frame: CGRect(x: left + 170, y: 100, width: 200, height: 15))
        cursorSlider.minimumValue = 0.1
        cursorSlider.maximumValue = 2.0
        cursorSlider.value = 1.0
        cursorSlider.isContinuous = false
        cursorSlider.isEnabled = false
        cursorSlider.addTarget(self, action: #selector(sliderValueChanged(sender:)), for: .valueChanged)
        self.cursorSensitiveLab = cursorlab
        self.cursorSlider = cursorSlider
        
        let volumelab = UILabel(frame: CGRect(x: left + 10, y: 140, width: 150, height: 25))
        volumelab.backgroundColor = UIColor.clear
        volumelab.font = UIFont.systemFont(ofSize: 15)
        volumelab.textColor = UIColor.black
        volumelab.text = "音量增益系数:1.0"
        volumelab.textAlignment = .left
        let volumeSlider = UISlider(frame: CGRect(x: left + 170, y: 140, width: 200, height: 15))
        volumeSlider.minimumValue = 0.1
        volumeSlider.maximumValue = 10.0
        volumeSlider.value = 1.0
        volumeSlider.isContinuous = false
        volumeSlider.addTarget(self, action: #selector(sliderValueChanged(sender:)), for: .valueChanged)
        self.volumeLab = volumelab
        self.volumeSlider = volumeSlider

        self.bitrateLevel = ["2M30fps", "4M45fps", "8M60fps"]
        self.bitrateLevelIndex = 1
        self.bitrateBtn = createBtnFrame(frame: CGRect(x: left + 10, y: 180, width: 70, height: 25), title: self.bitrateLevel?[self.bitrateLevelIndex!] as! String)
        
        self.clearKeyBtn = createBtnFrame(frame: CGRect(x: left + 10, y: 220, width: 70, height: 25), title: "按键清除")
        
        self.capsLockBtn = createBtnFrame(frame: CGRect(x: left + 90, y: 220, width: 70, height: 25), title: "查询大写")
        
        self.rotateViewBtn = createBtnFrame(frame: CGRect(x: left + 10, y: 260, width: 70, height: 25), title: "旋转视图")
        
        self.touchViewBtn = createBtnFrame(frame: CGRect(x: left + 90, y: 260, width: 70, height: 25), title: "使用触屏")
        
        self.padViewBtn = createBtnFrame(frame: CGRect(x: left + 170, y: 260, width: 70, height: 25), title: "按键开")
        self.restartBtn = createBtnFrame(frame: CGRect(x: selfWidth - 80, y: 80, width: 70, height: 25), title: "重启游戏")
        self.pauseBtn = createBtnFrame(frame: CGRect(x: selfWidth - 80, y: 120, width: 70, height: 25), title: "暂停游戏")
        self.stopGameBtn = createBtnFrame(frame: CGRect(x: selfWidth - 80, y: 160, width: 70, height: 25), title: "结束游戏")
        self.enableLocalAudioBtn = createBtnFrame(frame: CGRect(x: selfWidth - 80, y: 260, width: 70, height: 25), title: "开麦克风")
        self.patseTextBtn = createBtnFrame(frame: CGRect(x: left + 10, y: 300, width: 70, height: 25), title: "复制文本")
        self.changeResBtn = createBtnFrame(frame: CGRect(x: left + 90, y: 300, width: 70, height: 25), title: "改变分辨率")
        self.createDCBtn = createBtnFrame(frame: CGRect(x: left + 170, y: 300, width: 70, height: 25), title: "创建数据通道")
        self.sendDCDataBtn = createBtnFrame(frame: CGRect(x: left + 250, y: 300, width: 70, height: 25), title: "发送数据")
        self.allInfo = UILabel(frame: CGRect(x: left + 10, y: selfHeight - 80, width: 600, height: 70))
        self.allInfo?.backgroundColor = UIColor.clear
        self.allInfo?.font = UIFont.systemFont(ofSize: 10)
        self.allInfo?.textColor = UIColor(white: 0.2, alpha: 0.8)
        self.allInfo?.textAlignment = .left
        self.allInfo?.numberOfLines = 0
        self.allInfo?.lineBreakMode = .byWordWrapping
        
        self.addSubview(self.bitrateBtn!)
        self.addSubview(self.enableKeyboardBtn!)
        self.addSubview(self.restartBtn!)
        self.addSubview(self.pauseBtn!)
        self.addSubview(self.stopGameBtn!)
        self.addSubview(self.allInfo!)
        self.addSubview(self.clearKeyBtn!)
        self.addSubview(self.capsLockBtn!)
        self.addSubview(self.rotateViewBtn!)
        self.addSubview(self.touchViewBtn!)
        self.addSubview(self.padViewBtn!)
        self.addSubview(self.cursorBtn1!)
        self.addSubview(self.cursorBtn2!)
        self.addSubview(self.cursorBtn3!)
        self.addSubview(self.cursorBtn4!)
        self.addSubview(self.cursorSensitiveLab!)
        self.addSubview(self.cursorSlider!)
        self.addSubview(self.volumeLab!)
        self.addSubview(self.volumeSlider!)
        self.addSubview(self.enableLocalAudioBtn!)
        self.addSubview(self.changeResBtn!)
        self.addSubview(self.patseTextBtn!)
        self.addSubview(self.createDCBtn!)
        self.addSubview(self.sendDCDataBtn!)
    }

    func setAllDebugInfo(_ allInfo: [AnyHashable: Any]) {
        let all = allInfo.description.replacingOccurrences(of: "\n", with: " ")
        self.allInfo?.text = all
    }
}
